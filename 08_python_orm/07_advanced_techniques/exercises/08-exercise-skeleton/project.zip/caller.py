import os

import django
from django.core.exceptions import ValidationError

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()


from decimal import Decimal
from main_app.models import Product, DiscountedProduct

# Import your models here

discounted_product = DiscountedProduct.objects.create(name="Gaming Mouse", price=Decimal(120.00))

discounted_price = discounted_product.calculate_price_without_discount()
print(f"Price Without Discount for {discounted_product.name}: ${discounted_price:.2f}")