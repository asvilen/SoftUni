from project.driver import Driver


class Race:
    def __init__(self, name: str):
        self.name = name
        self.drivers = []
